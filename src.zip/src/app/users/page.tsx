'use client';

import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/Card';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { Badge } from '@/components/ui/Badge';
import { usersAPI } from '@/lib/api';
import { User } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Edit, Trash2, Eye } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/Button';

interface UserForm {
  firstName: string;
  lastName: string;
  username: string;
  email: string;
  phone: string;
  password: string;
  aadharNumber?: string;
  address?: string;
  roles: string[];
}

export default function UsersPage() {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedRoles, setSelectedRoles] = useState<string[]>([]);
  const [viewingUser, setViewingUser] = useState<User | null>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { hasRole, user: currentUser } = useAuth();
  const router = useRouter();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<UserForm>();

  useEffect(() => {
    if (!hasRole(['Admin'])) {
      router.push('/dashboard');
      return;
    }
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const response = await usersAPI.getAll();
      setUsers(response.data);
      setFilteredUsers(response.data);
    } catch (error) {
      console.error('Error loading users:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    console.log('Search effect triggered:', { searchQuery, usersLength: users.length });
    const filtered = users.filter(user => {
      const query = searchQuery.toLowerCase();
      const matches = (
        user.firstName.toLowerCase().includes(query) ||
        user.lastName.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query) ||
        user.username.toLowerCase().includes(query) ||
        user.phone.includes(query) ||
        user.roles.some(role => role.toLowerCase().includes(query))
      );
      console.log(`User ${user.firstName} matches query "${query}":`, matches);
      return matches;
    });
    console.log('Setting filtered users:', filtered.length);
    setFilteredUsers(filtered);
  }, [searchQuery, users]);

  const openModal = (user?: User) => {
    if (user) {
      setEditingUser(user);
      setSelectedRoles(user.roles);
      reset({
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        phone: user.phone,
        aadharNumber: user.aadharNumber,
        address: user.address,
        password: '',
      });
    } else {
      setEditingUser(null);
      setSelectedRoles(['Sales Man']);
      reset({});
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingUser(null);
    setSelectedRoles([]);
    reset();
  };

  const toggleRole = (role: string) => {
    if (selectedRoles.includes(role)) {
      setSelectedRoles(selectedRoles.filter(r => r !== role));
    } else {
      setSelectedRoles([...selectedRoles, role]);
    }
  };

  const onSubmit = async (data: UserForm) => {
    if (selectedRoles.length === 0) {
      alert('Please select at least one role');
      return;
    }

    try {
      setIsSubmitting(true);
      const userData = { ...data, roles: selectedRoles };
      if (editingUser) {
        const { password, username, ...updateData } = userData;
        await usersAPI.update(editingUser._id, updateData);
      } else {
        await usersAPI.create(userData);
      }
      await loadUsers();
      closeModal();
    } catch (error: any) {
      alert(error.response?.data?.message || 'Error saving user');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleViewUser = async (user: User) => {
    try {
      const response = await usersAPI.getById(user._id);
      setViewingUser(response.data);
      setIsViewModalOpen(true);
    } catch (error: any) {
      console.error('Error fetching user details:', error);
      alert('Error fetching user details: ' + (error.response?.data?.message || 'Unknown error'));
    }
  };

  const closeViewModal = () => {
    setIsViewModalOpen(false);
    setViewingUser(null);
  };

  const handleDelete = async (id: string) => {
    if (id === currentUser?._id) {
      alert('You cannot delete your own account');
      return;
    }
    if (confirm('Are you sure you want to delete this user?')) {
      try {
        await usersAPI.delete(id);
        await loadUsers();
      } catch (error: any) {
        alert(error.response?.data?.message || 'Error deleting user');
      }
    }
  };

  const getRoleBadge = (role: string) => {
    const colors: Record<string, 'default' | 'success' | 'info' | 'danger'> = {
      Admin: 'danger',
      Manager: 'info',
      'Sales Man': 'success',
    };
    return <Badge key={role} variant={colors[role] || 'default'}>{role}</Badge>;
  };

  if (!hasRole(['Admin'])) return null;

  return (
    <DashboardLayout>
      <div className="space-y-4 sm:space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">User Management</h1>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search users..."
                value={searchQuery}
                onChange={(e) => {
                  console.log('Search input changed:', e.target.value);
                  setSearchQuery(e.target.value);
                }}
                className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm sm:text-base"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              {searchQuery && (
                <button
                  onClick={() => {
                    console.log('Clearing search');
                    setSearchQuery('');
                  }}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => openModal()}
              className="inline-flex items-center justify-center px-4 sm:px-5 py-2 bg-blue-600 text-white rounded-lg shadow-lg hover:bg-blue-700 transition text-sm sm:text-base whitespace-nowrap"
            >
              <Plus className="h-4 w-4 sm:h-5 sm:w-5 mr-2" /> Add User
            </motion.button>
          </div>
        </div>

        {/* Search Results Info */}
        {!loading && (
          <div className="text-sm text-gray-600">
            {filteredUsers.length === users.length ? (
              `Showing all ${users.length} users`
            ) : (
              `Found ${filteredUsers.length} of ${users.length} users`
            )}
          </div>
        )}

        {/* Animated User Cards */}
        {loading ? (
          <div className="flex justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 sm:h-10 sm:w-10 border-4 border-t-primary-600"></div>
          </div>
        ) : filteredUsers.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-500 text-lg">
              {searchQuery ? (
                `No users found for "${searchQuery}"`
              ) : (
                "No users found."
              )}
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            <AnimatePresence>
              {filteredUsers.map(user => (
                <motion.div
                  key={user._id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  whileHover={{ scale: 1.03, boxShadow: '0 10px 20px rgba(0,0,0,0.12)' }}
                  transition={{ duration: 0.3 }}
                  className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-lg border border-gray-100"
                >
                  <div className="flex items-center gap-3 sm:gap-4">
                    <div className="h-12 w-12 sm:h-16 sm:w-16 rounded-full bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center text-white font-bold text-lg sm:text-xl flex-shrink-0">
                      {user.firstName?.[0]}{user.lastName?.[0]}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-900 text-sm sm:text-base truncate">{user.firstName} {user.lastName}</p>
                      <p className="text-gray-500 text-xs sm:text-sm truncate">{user.email}</p>
                      <div className="flex flex-wrap gap-1 sm:gap-2 mt-1 sm:mt-2">
                        {user.roles.map(getRoleBadge)}
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end gap-2 sm:gap-3 mt-3 sm:mt-4">
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => handleViewUser(user)}
                      className="px-2 sm:px-3 py-1.5 sm:py-1 rounded bg-indigo-500 text-white flex items-center gap-1 text-xs sm:text-sm"
                    >
                      <Eye className="h-3 w-3 sm:h-4 sm:w-4" /> <span className="hidden sm:inline">View</span>
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.95 }}
                      onClick={() => openModal(user)}
                      className="px-2 sm:px-3 py-1.5 sm:py-1 rounded bg-blue-500 text-white flex items-center gap-1 text-xs sm:text-sm"
                    >
                      <Edit className="h-3 w-3 sm:h-4 sm:w-4" /> <span className="hidden sm:inline">Edit</span>
                    </motion.button>
                    {user._id !== currentUser?._id && (
                      <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.95 }}
                        onClick={() => handleDelete(user._id)}
                        className="px-2 sm:px-3 py-1.5 sm:py-1 rounded bg-red-500 text-white flex items-center gap-1 text-xs sm:text-sm"
                      >
                        <Trash2 className="h-3 w-3 sm:h-4 sm:w-4" /> <span className="hidden sm:inline">Delete</span>
                      </motion.button>
                    )}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}

        {/* User Modal */}
        <Modal isOpen={isModalOpen} onClose={closeModal} title={editingUser ? 'Edit User' : 'Add User'} size="lg">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-5">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="First Name" {...register('firstName', { required: 'First name is required' })} error={errors.firstName?.message} />
              <Input label="Last Name" {...register('lastName', { required: 'Last name is required' })} error={errors.lastName?.message} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Username" {...register('username', { required: !editingUser ? 'Username required' : false })} error={errors.username?.message} disabled={!!editingUser} />
              <Input label="Email" type="email" {...register('email', { required: 'Email is required', pattern: { value: /^\S+@\S+$/i, message: 'Invalid email' } })} error={errors.email?.message} />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input label="Phone" {...register('phone', { required: 'Phone is required', pattern: { value: /^\d{10}$/, message: 'Phone must be 10 digits' } })} error={errors.phone?.message} />
              <Input label={editingUser ? 'New Password (leave blank to keep)' : 'Password'} type="password" {...register('password', { required: !editingUser ? 'Password is required' : false, minLength: { value: 6, message: 'Min 6 chars' } })} error={errors.password?.message} />
            </div>
            <Input label="Aadhar Number" {...register('aadharNumber')} />
            <Input label="Address" {...register('address')} />

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Roles</label>
              <div className="flex flex-wrap gap-2">
                {['Admin', 'Manager', 'Sales Man'].map(role => (
                  <motion.button key={role} type="button" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }} onClick={() => toggleRole(role)} className={`px-3 py-1 rounded-full text-sm font-medium transition-colors ${selectedRoles.includes(role) ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>{role}</motion.button>
                ))}
              </div>
              {selectedRoles.length === 0 && <p className="text-red-500 text-sm mt-1">Please select at least one role</p>}
            </div>

            <div className="flex justify-end gap-3">
              <Button type="button" variant="secondary" onClick={closeModal}>Cancel</Button>
              <Button type="submit" isLoading={isSubmitting}>{editingUser ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </Modal>

        {/* View User Modal */}
        <Modal isOpen={isViewModalOpen} onClose={closeViewModal} title="User Details" size="md">
          {viewingUser && (
            <div className="space-y-4">
              {/* User Avatar and Basic Info */}
              <div className="flex items-center gap-4 pb-4 border-b">
                <div className="h-20 w-20 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold text-2xl">
                  {viewingUser.firstName?.[0]}{viewingUser.lastName?.[0]}
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">
                    {viewingUser.firstName} {viewingUser.lastName}
                  </h3>
                  <p className="text-gray-500">@{viewingUser.username}</p>
                  <div className="flex gap-2 mt-2">
                    {viewingUser.roles.map(getRoleBadge)}
                  </div>
                </div>
              </div>

              {/* User Details Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Email</label>
                    <p className="text-gray-900">{viewingUser.email}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Phone</label>
                    <p className="text-gray-900">{viewingUser.phone}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Address</label>
                    <p className="text-gray-900">{viewingUser.address || 'Not provided'}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium text-gray-500">Aadhar Number</label>
                    <p className="text-gray-900">{viewingUser.aadharNumber || 'Not provided'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Status</label>
                    <p className="text-gray-900">
                      {viewingUser.isActive ? (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                          Active
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                          Inactive
                        </span>
                      )}
                    </p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-500">Created</label>
                    <p className="text-gray-900">
                      {new Date(viewingUser.createdAt).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}
                    </p>
                  </div>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex justify-end gap-3 pt-4 border-t">
                <Button type="button" variant="secondary" onClick={closeViewModal}>
                  Close
                </Button>
                <Button 
                  type="button" 
                  onClick={() => {
                    closeViewModal();
                    openModal(viewingUser);
                  }}
                >
                  Edit User
                </Button>
              </div>
            </div>
          )}
        </Modal>
      </div>
    </DashboardLayout>
  );
}
