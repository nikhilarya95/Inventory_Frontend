'use client';

import React, { useEffect, useState } from 'react';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, CardContent } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Input } from '@/components/ui/Input';
import { Modal } from '@/components/ui/Modal';
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from '@/components/ui/Table';
import { customersAPI } from '@/lib/api';
import { Customer } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { formatCurrency } from '@/lib/utils';

interface CustomerForm {
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  shopName: string;
  gst?: string;
  address: string;
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [filteredCustomers, setFilteredCustomers] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { hasRole } = useAuth();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<CustomerForm>();

  useEffect(() => {
    loadCustomers();
  }, []);

  const loadCustomers = async () => {
    try {
      const response = await customersAPI.getAll();
      setCustomers(response.data);
      setFilteredCustomers(response.data);
    } catch (error) {
      console.error('Error loading customers:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const filtered = customers.filter(customer => {
      const query = searchQuery.toLowerCase();
      return (
        customer.firstName.toLowerCase().includes(query) ||
        customer.lastName.toLowerCase().includes(query) ||
        customer.email.toLowerCase().includes(query) ||
        customer.phone.includes(query) ||
        customer.shopName.toLowerCase().includes(query) ||
        customer.gst?.toLowerCase().includes(query) ||
        customer.address.toLowerCase().includes(query) ||
        customer.customerId.toLowerCase().includes(query)
      );
    });
    setFilteredCustomers(filtered);
  }, [searchQuery, customers]);

  const openModal = (customer?: Customer) => {
    if (customer) {
      setEditingCustomer(customer);
      reset({
        firstName: customer.firstName,
        lastName: customer.lastName,
        email: customer.email,
        phone: customer.phone,
        shopName: customer.shopName,
        gst: customer.gst,
        address: customer.address,
      });
    } else {
      setEditingCustomer(null);
      reset({});
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingCustomer(null);
    reset();
  };

  const onSubmit = async (data: CustomerForm) => {
    try {
      setIsSubmitting(true);
      if (editingCustomer) {
        await customersAPI.update(editingCustomer._id, data);
      } else {
        await customersAPI.create(data);
      }
      await loadCustomers();
      closeModal();
    } catch (error: any) {
      alert(error.response?.data?.message || 'Error saving customer');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Are you sure you want to delete this customer?')) {
      try {
        await customersAPI.delete(id);
        await loadCustomers();
      } catch (error: any) {
        alert(error.response?.data?.message || 'Error deleting customer');
      }
    }
  };

  const canEdit = hasRole(['Admin', 'Manager']);

  return (
    <DashboardLayout>
      <div className="space-y-4 sm:space-y-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">Customers</h1>
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1 max-w-md">
              <input
                type="text"
                placeholder="Search customers..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-10 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-sm sm:text-base"
              />
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
                <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
            {canEdit && (
              <Button onClick={() => openModal()} className="whitespace-nowrap">
                <Plus className="h-4 w-4 mr-2" />
                Add Customer
              </Button>
            )}
          </div>
        </div>

        {/* Search Results Info */}
        {!loading && (
          <div className="text-sm text-gray-600">
            {filteredCustomers.length === customers.length ? (
              `Showing all ${customers.length} customers`
            ) : (
              `Found ${filteredCustomers.length} of ${customers.length} customers`
            )}
          </div>
        )}

        <Card>
          <CardContent>
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
              </div>
            ) : filteredCustomers.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-500 text-lg">
                  {searchQuery ? (
                    `No customers found for "${searchQuery}"`
                  ) : (
                    "No customers found."
                  )}
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
  {filteredCustomers.map((customer) => (
    <div
      key={customer._id}
  className="group relative rounded-2xl border bg-white shadow-sm 
             hover:shadow-2xl transition-all duration-300 ease-out 
             transform hover:scale-[1.03] cursor-pointer overflow-hidden"
   >
      {/* Top Gradient Header */}
      <div className="h-28 bg-gradient-to-r from-primary-600 to-primary-400 p-4 text-white flex justify-between">
        <div>
          <p className="text-lg font-semibold">{customer.shopName}</p>
          <p className="text-sm opacity-90">
            {customer.firstName} {customer.lastName}
          </p>
        </div>

        {/* Edit/Delete Buttons */}
        {canEdit && (
          <div className="flex flex-col space-y-2">
            <button
              onClick={() => openModal(customer)}
              className="bg-white/10 hover:bg-white/20 p-1 rounded-md transition"
            >
              <Edit className="h-4 w-4" />
            </button>
            <button
              onClick={() => handleDelete(customer._id)}
              className="bg-white/10 hover:bg-white/20 p-1 rounded-md transition"
            >
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        )}
      </div>

      {/* Body Content */}
      <div className="p-5 space-y-3">
        <div>
          <p className="text-xs text-gray-500">Email</p>
          <p className="text-sm font-medium">{customer.email}</p>
        </div>

        <div>
          <p className="text-xs text-gray-500">Phone</p>
          <p className="text-sm font-medium">{customer.phone}</p>
        </div>

        <div>
          <p className="text-xs text-gray-500">GST Number</p>
          <p className="text-sm font-medium">{customer.gst || '-'}</p>
        </div>

        <div>
          <p className="text-xs text-gray-500">Address</p>
          <p className="text-sm font-medium">{customer.address}</p>
        </div>

        {/* Total Due With Badge */}
        <div className="pt-2">
          <p className="text-xs text-gray-500">Total Due</p>

          <span
            className={`inline-block mt-1 px-3 py-1 text-sm font-semibold rounded-full 
            ${
              customer.totalDue > 0
                ? 'bg-red-100 text-red-700'
                : 'bg-green-100 text-green-700'
            }`}
          >
            {formatCurrency(customer.totalDue)}
          </span>
        </div>
      </div>

      {/* Floating "Customer ID" Badge */}
      <div className="absolute top-24 left-4 bg-white shadow-md px-3 py-1 rounded-full text-xs font-medium">
        ID: {customer.customerId}
      </div>
    </div>
  ))}

  {filteredCustomers.length === 0 && !searchQuery && (
    <p className="text-gray-500 text-center col-span-full">No customers found</p>
  )}
</div>
            )}
          </CardContent>
        </Card>

        <Modal isOpen={isModalOpen} onClose={closeModal} title={editingCustomer ? 'Edit Customer' : 'Add Customer'} size="lg">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Input label="First Name" {...register('firstName', { required: 'First name is required' })} error={errors.firstName?.message} />
              <Input label="Last Name" {...register('lastName', { required: 'Last name is required' })} error={errors.lastName?.message} />
            </div>
            <Input label="Shop Name" {...register('shopName', { required: 'Shop name is required' })} error={errors.shopName?.message} />
            <div className="grid grid-cols-2 gap-4">
              <Input label="Email" type="email" {...register('email', { required: 'Email is required', pattern: { value: /^\S+@\S+$/i, message: 'Invalid email' } })} error={errors.email?.message} />
              <Input label="Phone" {...register('phone', { required: 'Phone is required', pattern: { value: /^\d{10}$/, message: 'Phone must be 10 digits' } })} error={errors.phone?.message} />
            </div>
            <Input label="GST Number" {...register('gst')} />
            <Input label="Address" {...register('address', { required: 'Address is required' })} error={errors.address?.message} />
            <div className="flex justify-end space-x-3">
              <Button type="button" variant="secondary" onClick={closeModal}>Cancel</Button>
              <Button type="submit" isLoading={isSubmitting}>{editingCustomer ? 'Update' : 'Create'}</Button>
            </div>
          </form>
        </Modal>
      </div>
    </DashboardLayout>
  );
}
